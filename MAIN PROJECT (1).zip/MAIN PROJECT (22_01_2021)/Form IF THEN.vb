﻿Public Class Form_IF_THEN
    Private Sub Proses_Click(sender As Object, e As EventArgs) Handles Proses.Click
        Dim Ket As String
        Ket = ""
        If Val(Nilai.Text) >= 56 Then
            Ket = "LULUS"
        End If
        TKET.Text = Ket
    End Sub
End Class