﻿Public Class Index_Array_Combobox
    Private Sub Index_Array_Combobox_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim i As Integer
        Dim murid() As String = {"Ayu", "Desi", "Karina", "Irene", "Wendy"}

        ComboBox1.Items.Add(murid(2))

        For i = 0 To 4
            ComboBox2.Items.Add(murid(i))
        Next
    End Sub
End Class