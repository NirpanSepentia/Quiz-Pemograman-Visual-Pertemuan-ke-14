﻿Public Class Form_MessageBox
    Private Sub btnPesan1_Click(sender As Object, e As EventArgs) Handles btnPesan1.Click
        MsgBox("COBA BELAJAR VB.Net")
    End Sub

    Private Sub btnPesan2_Click(sender As Object, e As EventArgs) Handles btnPesan2.Click
        MsgBox("Tanda Seru!", MsgBoxStyle.Exclamation, "Baca Pesan")
    End Sub

    Private Sub btnPesan3_Click(sender As Object, e As EventArgs) Handles btnPesan3.Click
        MsgBox("Tanda Information", MsgBoxStyle.Information, "Baca Pesan")
    End Sub

    Private Sub btnPesan4_Click(sender As Object, e As EventArgs) Handles btnPesan4.Click
        MsgBox("Tanda Error", MsgBoxStyle.Critical, "Baca Pesan")
    End Sub

    Private Sub btnUbah_Click(sender As Object, e As EventArgs) Handles btnUbah.Click
        Label1.Text = "Percobaan ubah text di VB.Net"
        btnPesanKeluar.Text = "OK"
    End Sub

    Private Sub btnHapus_Click(sender As Object, e As EventArgs) Handles btnHapus.Click
        Label1.Text = ""
    End Sub

    Private Sub btnPesanKeluar_Click(sender As Object, e As EventArgs) Handles btnPesanKeluar.Click
        Dim pesan As String
        pesan = MsgBox("Anda yakin ingin keluar dari program?", MsgBoxStyle.Question + MsgBoxStyle.OkCancel, "Exit")
        If pesan = vbOK Then
            Me.Close()
        End If
    End Sub

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnEnd_Click(sender As Object, e As EventArgs) Handles btnEnd.Click
        End
    End Sub
End Class