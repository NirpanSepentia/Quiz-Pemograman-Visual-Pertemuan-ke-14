﻿Public Class Perulangan_While
    Private Sub BtnProses_Click(sender As Object, e As EventArgs) Handles BtnProses.Click
        Dim i As Integer
        i = 1
        LboxHasil.Items.Clear()
        While i <= 10
            LboxHasil.Items.Add(i)
            i += 1
        End While
    End Sub
End Class