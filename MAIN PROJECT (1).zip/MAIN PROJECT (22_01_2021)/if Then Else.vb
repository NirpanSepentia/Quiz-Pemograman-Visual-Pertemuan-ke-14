﻿Public Class if_Then_Else
    Private Sub TNilai_TextChanged(sender As Object, e As EventArgs) Handles TNilai.TextChanged

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim Ket As String
        Ket = ""
        If Val(TNilai.Text) >= 56 Then
            Ket = "LULUS"
        Else
            Ket = "TIDAK LULUS"
        End If
        Tket.Text = Ket

    End Sub
End Class