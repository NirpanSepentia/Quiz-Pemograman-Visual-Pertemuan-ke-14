﻿Public Class Form1
    Dim SlidingMenu As String = "close"
    Private Sub HelloWorldToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelloWorldToolStripMenuItem.Click
        Form_HelloWorld.Show()

    End Sub

    Private Sub MessageBoxToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MessageBoxToolStripMenuItem.Click
        Form_MessageBox.Show()

    End Sub

    Private Sub OperatorRelasiToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OperatorRelasiToolStripMenuItem.Click
        program_operator_relasi.Show()
    End Sub

    Private Sub OperatorPerhitungan1ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OperatorPerhitungan1ToolStripMenuItem.Click
        Operator_Perhitungan.Show()
    End Sub

    Private Sub ChangeKursToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ChangeKursToolStripMenuItem.Click
        ProgramChangeKurs.Show()
    End Sub

    Private Sub OperatorPerhitungan2ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles OperatorPerhitungan2ToolStripMenuItem.Click
        OperatorPerhitungan2.Show()



    End Sub

    Private Sub ConvertTipeDataToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ConvertTipeDataToolStripMenuItem.Click
        Form_ConvertTipeData.Show()
    End Sub

    Private Sub IfThenElseToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles IfThenElseToolStripMenuItem.Click
        if_Then_Else.Show()

    End Sub

    Private Sub IfElseIfEndIfRadiobuttonToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles IfElseIfEndIfRadiobuttonToolStripMenuItem.Click
        if_Elself_End_if_radioButton.Show()
    End Sub

    Private Sub SelectCaseJurusanToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SelectCaseJurusanToolStripMenuItem.Click
        selectcaseJurusan.Show()
    End Sub

    Private Sub PerhitunganGajiKaryawanToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PerhitunganGajiKaryawanToolStripMenuItem.Click
        Perhitungan_Gaji.Show()

    End Sub

    Private Sub ProgramSPBUToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProgramSPBUToolStripMenuItem.Click
        SPBU.Show()

    End Sub

    Private Sub SelectCaseNilaiToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SelectCaseNilaiToolStripMenuItem.Click
        select_case.Show()
    End Sub

    Private Sub PerhitunganNilaiAkhirDanPenentuanGradeToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PerhitunganNilaiAkhirDanPenentuanGradeToolStripMenuItem.Click

        perhitungan_nilai_akhir_dan_penentuan_G.Show()
    End Sub

    Private Sub IfElseIfEndIfComboboxToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles IfElseIfEndIfComboboxToolStripMenuItem.Click

        Form2.Show()
    End Sub

    Private Sub SelectCaseListBoxToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SelectCaseListBoxToolStripMenuItem.Click

        ListBox.Show()
    End Sub

    Private Sub PerulanganForNextDateToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PerulanganForNextDateToolStripMenuItem.Click

        Pengulangan.Show()
    End Sub

    Private Sub EntryDataMahasiswaToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles EntryDataMahasiswaToolStripMenuItem.Click

        ProgramEntryDataMahasiswa.Show()
    End Sub

    Private Sub SelectCasePaketMakananToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles SelectCasePaketMakananToolStripMenuItem.Click

        Select_Case_Paket_Makanan.Show()

    End Sub

    Private Sub PerulanganForNextInputToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PerulanganForNextInputToolStripMenuItem.Click

        ProgramPengulanganInput.Show()
    End Sub

    Private Sub PerulanganWhileEndWhileToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PerulanganWhileEndWhileToolStripMenuItem.Click
        Perulangan_While.Show()
    End Sub

    Private Sub PercabanganIfToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PercabanganIfToolStripMenuItem.Click
        Percabangan_If.Show()

    End Sub

    Private Sub PembayaranToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PembayaranToolStripMenuItem.Click
        Pembayaran.Show()

    End Sub

    Private Sub TampilanDataToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles TampilanDataToolStripMenuItem.Click
        Tampilan_Data.Show()
    End Sub

    Private Sub PerulanganForNextStepToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PerulanganForNextStepToolStripMenuItem.Click
        perulangan_for_next___step__.Show()
    End Sub

    Private Sub PerulanganDoUntilLoopToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PerulanganDoUntilLoopToolStripMenuItem.Click
        perulanga_do_until___loop.Show()
    End Sub

    Private Sub PracticeOfArray01ToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PracticeOfArray01ToolStripMenuItem.Click
        practice_of_array_01.Show()
    End Sub

    Private Sub IfThenToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles IfThenToolStripMenuItem.Click

        Form_IF_THEN.Show()

    End Sub

    Private Sub IfElseIfEndIfCheckboxToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles IfElseIfEndIfCheckboxToolStripMenuItem.Click

        Form_IF_ELSE_IF.Show()

    End Sub

    Private Sub NestedIfToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles NestedIfToolStripMenuItem.Click

        Nested_IF.Show()

    End Sub

    Private Sub PerulanganForNextToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PerulanganForNextToolStripMenuItem.Click

        Perulangan_For_Next.Show()
    End Sub

    Private Sub BulanIndexToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles BulanIndexToolStripMenuItem.Click

        BulanIndex.Show()
    End Sub

    Private Sub MaskapaiPenerbanganToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles MaskapaiPenerbanganToolStripMenuItem.Click

        Maskapai_Penerbangan.Show()
    End Sub

    Private Sub PerulanganDoWhileLoopToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles PerulanganDoWhileLoopToolStripMenuItem.Click

        Perulangan_Do_While_Loop.Show()

    End Sub

    Private Sub IndexArrayComboBoxToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles IndexArrayComboBoxToolStripMenuItem.Click

        Index_Array_Combobox.Show()
    End Sub

    Private Sub AplikasiGajiKaryawanToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AplikasiGajiKaryawanToolStripMenuItem.Click

        InputForm.Show()

    End Sub


    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label3.Text = Format(Now, "dddd, dd MMMM yyyy")
        Label4.Text = Format(Now, "HH:mm:ss")
    End Sub

    Private Sub btnSliding_Click(sender As Object, e As EventArgs) Handles btnSliding.Click
        Timer2.Start()
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        If SlidingMenu = "open" Then
            SlidingPanel.Width += 25
            If SlidingPanel.Width >= 250 Then
                Timer2.Stop()
                PictureBox1.Visible = True
                Label1.Visible = True
                Label2.Visible = True
                Label3.Visible = True
                Label4.Visible = True
                Label5.Visible = True
                Label6.Visible = True
                SlidingMenu = "close"
            End If
        Else
            SlidingPanel.Width -= 25
            If SlidingPanel.Width <= 50 Then
                Timer2.Stop()
                PictureBox1.Visible = False
                Label1.Visible = False
                Label2.Visible = False
                Label3.Visible = False
                Label4.Visible = False
                Label5.Visible = False
                Label6.Visible = False
                SlidingMenu = "open"
            End If
        End If
    End Sub
End Class
