﻿Public Class Form_ConvertTipeData
    Private Sub TextBox2_TextChanged(sender As Object, e As EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Dim harga, jumlah, total As Integer
        harga = CInt(TextBox2.Text)
        'jumlah = CInt(TextBox3.Text)
        total = harga * jumlah


        TextBox4.Text = CStr(total)


    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        End
    End Sub

    Private Sub Button8_Click(sender As Object, e As EventArgs) Handles Button8.Click
        Me.Close()

    End Sub
End Class