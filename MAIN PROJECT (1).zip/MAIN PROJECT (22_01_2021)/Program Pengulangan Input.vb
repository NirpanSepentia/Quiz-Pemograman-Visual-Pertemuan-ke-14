﻿Public Class ProgramPengulanganInput
    Private Sub CmdProses_Click(sender As Object, e As EventArgs) Handles CmdProses.Click
        Dim teks As String
        Dim Jumlah, i As Integer
        teks = TextBox1.Text
        Jumlah = TextBox2.Text
        For i = 1 To Jumlah
            ListBox1.Items.Add(i & ". " & teks)
        Next i

    End Sub
End Class