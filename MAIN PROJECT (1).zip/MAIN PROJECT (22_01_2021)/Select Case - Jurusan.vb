﻿Public Class selectcaseJurusan
    Private Sub TxtKode_TextChanged(sender As Object, e As EventArgs) Handles TxtKode.TextChanged
        Select Case TxtKode.Text
            Case "SI"
                LblJur.Text = "Sistem Informasi"
                LblProgram.Text = "Strata-1"
            Case "TI"
                LblJur.Text = "Teknik Informatika"
                LblProgram.Text = "Strata-1"
            Case Else
                LblJur.Text = "Jurusan Belum terdaftar"
                LblProgram.Text = "Program Tidak Tersedia"
        End Select
    End Sub
End Class