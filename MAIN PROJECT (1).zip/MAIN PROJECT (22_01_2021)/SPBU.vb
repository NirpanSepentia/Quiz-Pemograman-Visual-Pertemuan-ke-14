﻿Public Class SPBU
    Private Sub SPBU_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        cmbJenis.Items.Add("Mobil")
        cmbJenis.Items.Add("Motor")
    End Sub

    Private Sub btnProses_Click(sender As Object, e As EventArgs) Handles btnProses.Click
        Select Case (Me.cmbJenis.Text)
            Case ("Mobil")
                Me.Label9.Text = "4"
            Case ("Motor")
                Me.Label9.Text = "2"
        End Select


        If rbLiter.Checked = True Then
            Label10.Text = Val(tHarga.Text) * Val(tJumlah.Text)
            Label11.Text = tJumlah.Text
        End If
        If rbUang.Checked = True Then
            Label10.Text = tJumlah.Text
            Label11.Text = Val(tJumlah.Text) / Val(tHarga.Text)
            Label11.Text = FormatNumber(Label11.Text, 2)
        End If
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        tHarga.Text = ""
        tJumlah.Text = ""
        rbLiter.Checked = False
        rbUang.Checked = False
        Label9.Text = ""
        Label10.Text = ""
        Label11.Text = ""
        cmbJenis.Text = "Silahkan Pilih"

    End Sub
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()

    End Sub

End Class