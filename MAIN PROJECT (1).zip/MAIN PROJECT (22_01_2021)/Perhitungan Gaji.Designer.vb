﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Perhitungan_Gaji
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.btnProses = New System.Windows.Forms.Button()
        Me.btnHapus = New System.Windows.Forms.Button()
        Me.cmbJabatan = New System.Windows.Forms.ComboBox()
        Me.cmbGolongan = New System.Windows.Forms.ComboBox()
        Me.cmbNIP = New System.Windows.Forms.ComboBox()
        Me.tTotal = New System.Windows.Forms.TextBox()
        Me.tTunjangan = New System.Windows.Forms.TextBox()
        Me.tGaji = New System.Windows.Forms.TextBox()
        Me.tNama = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(71, 28)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(310, 22)
        Me.Label8.TabIndex = 36
        Me.Label8.Text = "PROGRAM PERHITUNGAN GAJI"
        '
        'btnProses
        '
        Me.btnProses.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnProses.Location = New System.Drawing.Point(122, 290)
        Me.btnProses.Name = "btnProses"
        Me.btnProses.Size = New System.Drawing.Size(176, 34)
        Me.btnProses.TabIndex = 35
        Me.btnProses.Text = "&Process"
        Me.btnProses.UseVisualStyleBackColor = True
        '
        'btnHapus
        '
        Me.btnHapus.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHapus.Location = New System.Drawing.Point(357, 357)
        Me.btnHapus.Name = "btnHapus"
        Me.btnHapus.Size = New System.Drawing.Size(75, 33)
        Me.btnHapus.TabIndex = 34
        Me.btnHapus.Text = "&Hapus"
        Me.btnHapus.UseVisualStyleBackColor = True
        '
        'cmbJabatan
        '
        Me.cmbJabatan.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbJabatan.FormattingEnabled = True
        Me.cmbJabatan.Location = New System.Drawing.Point(212, 219)
        Me.cmbJabatan.Name = "cmbJabatan"
        Me.cmbJabatan.Size = New System.Drawing.Size(65, 24)
        Me.cmbJabatan.TabIndex = 33
        Me.cmbJabatan.Text = "Pilih"
        '
        'cmbGolongan
        '
        Me.cmbGolongan.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbGolongan.FormattingEnabled = True
        Me.cmbGolongan.Location = New System.Drawing.Point(212, 142)
        Me.cmbGolongan.Name = "cmbGolongan"
        Me.cmbGolongan.Size = New System.Drawing.Size(56, 24)
        Me.cmbGolongan.TabIndex = 32
        Me.cmbGolongan.Text = "Pilih"
        '
        'cmbNIP
        '
        Me.cmbNIP.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmbNIP.FormattingEnabled = True
        Me.cmbNIP.Location = New System.Drawing.Point(212, 74)
        Me.cmbNIP.Name = "cmbNIP"
        Me.cmbNIP.Size = New System.Drawing.Size(56, 24)
        Me.cmbNIP.TabIndex = 31
        Me.cmbNIP.Text = "Plih"
        '
        'tTotal
        '
        Me.tTotal.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tTotal.Location = New System.Drawing.Point(212, 335)
        Me.tTotal.Name = "tTotal"
        Me.tTotal.Size = New System.Drawing.Size(86, 22)
        Me.tTotal.TabIndex = 30
        '
        'tTunjangan
        '
        Me.tTunjangan.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tTunjangan.Location = New System.Drawing.Point(212, 252)
        Me.tTunjangan.Name = "tTunjangan"
        Me.tTunjangan.Size = New System.Drawing.Size(86, 22)
        Me.tTunjangan.TabIndex = 29
        '
        'tGaji
        '
        Me.tGaji.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tGaji.Location = New System.Drawing.Point(212, 180)
        Me.tGaji.Name = "tGaji"
        Me.tGaji.Size = New System.Drawing.Size(86, 22)
        Me.tGaji.TabIndex = 28
        '
        'tNama
        '
        Me.tNama.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tNama.Location = New System.Drawing.Point(212, 107)
        Me.tNama.Name = "tNama"
        Me.tNama.Size = New System.Drawing.Size(123, 22)
        Me.tNama.TabIndex = 27
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(119, 335)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(57, 16)
        Me.Label7.TabIndex = 26
        Me.Label7.Text = "Total Gaji"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(119, 259)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(64, 16)
        Me.Label6.TabIndex = 25
        Me.Label6.Text = "Tunjangan"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(119, 219)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(50, 16)
        Me.Label5.TabIndex = 24
        Me.Label5.Text = "Jabatan"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(119, 183)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(28, 16)
        Me.Label4.TabIndex = 23
        Me.Label4.Text = "Gaji"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(119, 150)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(60, 16)
        Me.Label3.TabIndex = 22
        Me.Label3.Text = "Golongan"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(119, 114)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(37, 16)
        Me.Label2.TabIndex = 21
        Me.Label2.Text = "Nama"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(119, 77)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(27, 16)
        Me.Label1.TabIndex = 20
        Me.Label1.Text = "NIP"
        '
        'Perhitungan_Gaji
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DodgerBlue
        Me.ClientSize = New System.Drawing.Size(444, 402)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.btnProses)
        Me.Controls.Add(Me.btnHapus)
        Me.Controls.Add(Me.cmbJabatan)
        Me.Controls.Add(Me.cmbGolongan)
        Me.Controls.Add(Me.cmbNIP)
        Me.Controls.Add(Me.tTotal)
        Me.Controls.Add(Me.tTunjangan)
        Me.Controls.Add(Me.tGaji)
        Me.Controls.Add(Me.tNama)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Perhitungan_Gaji"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Program Perhitungan Gaji"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label8 As Label
    Friend WithEvents btnProses As Button
    Friend WithEvents btnHapus As Button
    Friend WithEvents cmbJabatan As ComboBox
    Friend WithEvents cmbGolongan As ComboBox
    Friend WithEvents cmbNIP As ComboBox
    Friend WithEvents tTotal As TextBox
    Friend WithEvents tTunjangan As TextBox
    Friend WithEvents tGaji As TextBox
    Friend WithEvents tNama As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class
