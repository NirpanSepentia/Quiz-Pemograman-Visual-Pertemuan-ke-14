﻿Public Class Form_IF_ELSE_IF
    Private Sub BTampil_Click(sender As Object, e As EventArgs) Handles BTampil.Click
        Dim pilihan As String
        pilihan = "Anda memilih "
        If chkSate.Checked = True Then
            pilihan = pilihan & "sate"
        ElseIf chkSoto.Checked = True Then
            pilihan = pilihan & "soto"
        ElseIf chkKare.Checked = True Then
            pilihan = pilihan & "kare"
        End If
        MsgBox(pilihan & ",pesan segera diantar")
    End Sub
End Class