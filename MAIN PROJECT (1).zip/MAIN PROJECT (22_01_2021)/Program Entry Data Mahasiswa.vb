﻿Public Class ProgramEntryDataMahasiswa
    Private Sub CmdProses_Click(sender As Object, e As EventArgs) Handles CmdProses.Click
        Label2.Text = "Selamat Datang " & ENAMA.Text
        If CmbJurusan.Text = "Sistem Informasi" Then
            Label3.Text = "Anda Masuk Jurusan Sistem Informasi"
        ElseIf CmbJurusan.Text = "Teknik Informatika" Then
            Label3.Text = "Anda Masuk Jurusan Teknik Informatika"
        ElseIf CmbJurusan.Text = "Teknik Industri" Then
            Label3.Text = "Anda Masuk Jurusan Teknik Industri"
        Else
            Label3.Text = "Anda Masuk Jurusan Bisnis Manajemen"
        End If

        If RbtLaki.Checked = True Then
            Label4.Text = "Anda Laki Laki !!"
        Else
            Label4.Text = "Anda Perempuan !!"
        End If
    End Sub

    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        CmbJurusan.Items.Clear()
        CmbJurusan.Items.Add("Sistem Informasi")
        CmbJurusan.Items.Add("Teknik Informatika")
        CmbJurusan.Items.Add("Teknik Industri")
        CmbJurusan.Items.Add("Bisnis Manajemen")
    End Sub
End Class