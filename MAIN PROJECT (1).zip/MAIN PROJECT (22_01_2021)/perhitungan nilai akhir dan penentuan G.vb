﻿Public Class perhitungan_nilai_akhir_dan_penentuan_G
    Private Sub bproses_Click(sender As Object, e As EventArgs) Handles bproses.Click
        TxtNA.Text = 0.25 * Val(TxtNtgs.Text) + 0.3 * Val(TxtNuts.Text) + 0.45 * Val(TxtNuas.Text)
        Select Case TxtNA.Text
            Case Is >= 81
                TxtNgrade.Text = "A"
            Case Is >= 71
                TxtNgrade.Text = "AB"
            Case Is >= 66
                TxtNgrade.Text = "B"
            Case Is >= 56
                TxtNgrade.Text = "C"
            Case Is >= 41
                TxtNgrade.Text = "D"
            Case Else
                TxtNgrade.Text = "E"
        End Select
    End Sub
End Class