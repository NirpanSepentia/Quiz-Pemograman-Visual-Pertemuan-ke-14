﻿Public Class Maskapai_Penerbangan
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim pesawat() As String = {"Garuda Indonesi", "Lion Ailiness", "Citilink", "Sriwijaya", "Batik,A.Aa"}
        MsgBox("Pilihan Maskapai Anda Adalah:" & pesawat(Val(TextBox1.Text) - 1))
    End Sub
End Class