﻿Public Class practice_of_array_01
    Private Sub Bclick_Click(sender As Object, e As EventArgs) Handles Bclick.Click
        Dim kota() As String = {"jakarta", "Batam", "Bandung"}
        Dim biaya As String

        If TextBox1.Text = "1" Then
            biaya = Val(TextBox2.Text) * 500000
        ElseIf TextBox1.Text = "2" Then
            biaya = Val(TextBox2.Text) * 450000
        ElseIf TextBox1.Text = "3" Then
            biaya = Val(TextBox2.Text) * 600000
        End If

        MsgBox("kota tujuan anda :  " & kota(Val(TextBox1.Text) - 1) & vbNewLine & "total tiket yang dibeli : " &
            TextBox2.Text & vbNewLine & "Total Biaya yang harus dibayarkan : IDR " & biaya)
    End Sub

End Class