﻿Public Class Tampilan_Data
    Private Sub Form3_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Indeks = 1
        ReDim Data(Indeks)
        TextBox1.Text = Indeks
    End Sub
    Private Structure DataMahasiswa
        Dim Nama As String
        Dim Nomor As String
        Dim Jurusan As String
        Dim Tanggal As String
        Dim Alamat As String
    End Structure
    Dim Indeks As Integer
    Dim Data() As DataMahasiswa
    Sub DaftarMahasiswa()
        'Produser DaftarMahsiswa
        Data(Indeks).Nama = TextBox2.Text
        Data(Indeks).Nomor = TextBox3.Text
        Data(Indeks).Jurusan = TextBox4.Text
        Data(Indeks).Tanggal = TextBox5.Text
        Data(Indeks).Alamat = TextBox6.Text
    End Sub
    Sub HapusDaftar()
        'Produser Hapus Daftar
        TextBox2.Text = ""
        TextBox3.Text = ""
        TextBox4.Text = ""
        TextBox5.Text = ""
        TextBox6.Text = ""
        TextBox2.Focus()
    End Sub
    Sub TampilanData()
        MsgBox("Informasi Data Mahasiswa Ke " & Indeks & Chr(10) &
               "Nama : " & Data(Indeks).Nama & Chr(10) &
               "NIM : " & Data(Indeks).Nomor & Chr(10) &
               "Jurusan : " & Data(Indeks).Jurusan & Chr(10) &
               "Tanggal Lahir : " & Data(Indeks).Tanggal & Chr(10) &
               "Alamat : " & Data(Indeks).Alamat, , "Data Mahasiswa")
    End Sub
    Sub TampilanForm()
        TextBox2.Text = Data(Indeks).Nama
        TextBox3.Text = Data(Indeks).Nomor
        TextBox4.Text = Data(Indeks).Jurusan
        TextBox5.Text = Data(Indeks).Tanggal
        TextBox6.Text = Data(Indeks).Alamat
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        HapusDaftar()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        DaftarMahasiswa()
        TampilanData()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If Indeks > LBound(Data) Then
            DaftarMahasiswa()
            Indeks = Indeks - 1
            TampilanForm()
        End If
        If Indeks = 0 Then Indeks = 1
        TextBox1.Text = Indeks
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        TextBox1.Text = Indeks
        If Indeks = UBound(Data) Then
            ReDim Preserve Data(Indeks + 1)
        End If
        DaftarMahasiswa() '
        Indeks = Indeks + 1
        TextBox1.Text = Indeks
        TampilanForm()
    End Sub
End Class