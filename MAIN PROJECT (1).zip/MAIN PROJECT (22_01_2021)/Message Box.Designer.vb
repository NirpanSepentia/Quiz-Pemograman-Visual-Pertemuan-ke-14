﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_MessageBox
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnPesan4 = New System.Windows.Forms.Button()
        Me.btnPesan3 = New System.Windows.Forms.Button()
        Me.btnPesan2 = New System.Windows.Forms.Button()
        Me.btnPesan1 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnPesanKeluar = New System.Windows.Forms.Button()
        Me.btnHapus = New System.Windows.Forms.Button()
        Me.btnUbah = New System.Windows.Forms.Button()
        Me.btnEnd = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.Panel1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.DodgerBlue
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(479, 62)
        Me.Panel1.TabIndex = 0
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial Narrow", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.Transparent
        Me.Label2.Location = New System.Drawing.Point(137, 20)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(210, 23)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "PROGRAM HELLO WORLD"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnPesan4)
        Me.GroupBox2.Controls.Add(Me.btnPesan3)
        Me.GroupBox2.Controls.Add(Me.btnPesan2)
        Me.GroupBox2.Controls.Add(Me.btnPesan1)
        Me.GroupBox2.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(38, 91)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(385, 85)
        Me.GroupBox2.TabIndex = 15
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Message Box"
        '
        'btnPesan4
        '
        Me.btnPesan4.Location = New System.Drawing.Point(289, 33)
        Me.btnPesan4.Name = "btnPesan4"
        Me.btnPesan4.Size = New System.Drawing.Size(75, 23)
        Me.btnPesan4.TabIndex = 3
        Me.btnPesan4.Text = "Pesan 4"
        Me.btnPesan4.UseVisualStyleBackColor = True
        '
        'btnPesan3
        '
        Me.btnPesan3.Location = New System.Drawing.Point(198, 33)
        Me.btnPesan3.Name = "btnPesan3"
        Me.btnPesan3.Size = New System.Drawing.Size(75, 23)
        Me.btnPesan3.TabIndex = 2
        Me.btnPesan3.Text = "Pesan 3"
        Me.btnPesan3.UseVisualStyleBackColor = True
        '
        'btnPesan2
        '
        Me.btnPesan2.Location = New System.Drawing.Point(108, 33)
        Me.btnPesan2.Name = "btnPesan2"
        Me.btnPesan2.Size = New System.Drawing.Size(75, 23)
        Me.btnPesan2.TabIndex = 1
        Me.btnPesan2.Text = "Pesan 2"
        Me.btnPesan2.UseVisualStyleBackColor = True
        '
        'btnPesan1
        '
        Me.btnPesan1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.btnPesan1.Location = New System.Drawing.Point(18, 33)
        Me.btnPesan1.Name = "btnPesan1"
        Me.btnPesan1.Size = New System.Drawing.Size(75, 23)
        Me.btnPesan1.TabIndex = 0
        Me.btnPesan1.Text = "Pesan 1"
        Me.btnPesan1.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.btnPesanKeluar)
        Me.GroupBox1.Controls.Add(Me.btnHapus)
        Me.GroupBox1.Controls.Add(Me.btnUbah)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(61, 196)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(341, 170)
        Me.GroupBox1.TabIndex = 14
        Me.GroupBox1.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(107, 22)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(88, 16)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Tampilan Tulisan"
        '
        'btnPesanKeluar
        '
        Me.btnPesanKeluar.Location = New System.Drawing.Point(105, 129)
        Me.btnPesanKeluar.Name = "btnPesanKeluar"
        Me.btnPesanKeluar.Size = New System.Drawing.Size(135, 23)
        Me.btnPesanKeluar.TabIndex = 8
        Me.btnPesanKeluar.Text = "Pesan Keluar"
        Me.btnPesanKeluar.UseVisualStyleBackColor = True
        '
        'btnHapus
        '
        Me.btnHapus.Location = New System.Drawing.Point(207, 58)
        Me.btnHapus.Name = "btnHapus"
        Me.btnHapus.Size = New System.Drawing.Size(79, 36)
        Me.btnHapus.TabIndex = 7
        Me.btnHapus.Text = "Hapus Text"
        Me.btnHapus.UseVisualStyleBackColor = True
        '
        'btnUbah
        '
        Me.btnUbah.Location = New System.Drawing.Point(46, 58)
        Me.btnUbah.Name = "btnUbah"
        Me.btnUbah.Size = New System.Drawing.Size(79, 36)
        Me.btnUbah.TabIndex = 6
        Me.btnUbah.Text = "Ubah Text"
        Me.btnUbah.UseVisualStyleBackColor = True
        '
        'btnEnd
        '
        Me.btnEnd.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnEnd.Location = New System.Drawing.Point(391, 407)
        Me.btnEnd.Name = "btnEnd"
        Me.btnEnd.Size = New System.Drawing.Size(75, 27)
        Me.btnEnd.TabIndex = 13
        Me.btnEnd.Text = "End"
        Me.btnEnd.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClose.Location = New System.Drawing.Point(310, 407)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(75, 27)
        Me.btnClose.TabIndex = 12
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'Form_MessageBox
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(478, 446)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnEnd)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.Panel1)
        Me.Name = "Form_MessageBox"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Message Box"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Panel1 As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents btnPesan4 As Button
    Friend WithEvents btnPesan3 As Button
    Friend WithEvents btnPesan2 As Button
    Friend WithEvents btnPesan1 As Button
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label1 As Label
    Friend WithEvents btnPesanKeluar As Button
    Friend WithEvents btnHapus As Button
    Friend WithEvents btnUbah As Button
    Friend WithEvents btnEnd As Button
    Friend WithEvents btnClose As Button
End Class
