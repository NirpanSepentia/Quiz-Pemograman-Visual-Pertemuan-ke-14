﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Percabangan_If
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnReset = New System.Windows.Forms.Button()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.tKet = New System.Windows.Forms.TextBox()
        Me.tGrade = New System.Windows.Forms.TextBox()
        Me.tTotal = New System.Windows.Forms.TextBox()
        Me.t40 = New System.Windows.Forms.TextBox()
        Me.t30 = New System.Windows.Forms.TextBox()
        Me.t20 = New System.Windows.Forms.TextBox()
        Me.t10 = New System.Windows.Forms.TextBox()
        Me.tUAS = New System.Windows.Forms.TextBox()
        Me.tUTS = New System.Windows.Forms.TextBox()
        Me.tTugas = New System.Windows.Forms.TextBox()
        Me.tAbsen = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Arial Rounded MT Bold", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.Color.White
        Me.Label12.Location = New System.Drawing.Point(137, 26)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(267, 22)
        Me.Label12.TabIndex = 51
        Me.Label12.Text = "Menghitung Nilai Mahasiswa"
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.ForeColor = System.Drawing.Color.Black
        Me.btnExit.Location = New System.Drawing.Point(129, 274)
        Me.btnExit.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(110, 70)
        Me.btnExit.TabIndex = 50
        Me.btnExit.Text = "&Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnReset
        '
        Me.btnReset.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnReset.ForeColor = System.Drawing.Color.Black
        Me.btnReset.Location = New System.Drawing.Point(36, 317)
        Me.btnReset.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnReset.Name = "btnReset"
        Me.btnReset.Size = New System.Drawing.Size(87, 27)
        Me.btnReset.TabIndex = 49
        Me.btnReset.Text = "&Reset"
        Me.btnReset.UseVisualStyleBackColor = True
        '
        'btnCalculate
        '
        Me.btnCalculate.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalculate.ForeColor = System.Drawing.Color.Black
        Me.btnCalculate.Location = New System.Drawing.Point(36, 274)
        Me.btnCalculate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(87, 35)
        Me.btnCalculate.TabIndex = 48
        Me.btnCalculate.Text = "&Calculate"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'tKet
        '
        Me.tKet.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tKet.Location = New System.Drawing.Point(361, 338)
        Me.tKet.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.tKet.Multiline = True
        Me.tKet.Name = "tKet"
        Me.tKet.Size = New System.Drawing.Size(137, 70)
        Me.tKet.TabIndex = 47
        '
        'tGrade
        '
        Me.tGrade.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tGrade.Location = New System.Drawing.Point(361, 303)
        Me.tGrade.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.tGrade.Name = "tGrade"
        Me.tGrade.Size = New System.Drawing.Size(52, 22)
        Me.tGrade.TabIndex = 46
        '
        'tTotal
        '
        Me.tTotal.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tTotal.Location = New System.Drawing.Point(361, 268)
        Me.tTotal.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.tTotal.Name = "tTotal"
        Me.tTotal.Size = New System.Drawing.Size(52, 22)
        Me.tTotal.TabIndex = 45
        '
        't40
        '
        Me.t40.Enabled = False
        Me.t40.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t40.Location = New System.Drawing.Point(361, 202)
        Me.t40.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.t40.Name = "t40"
        Me.t40.Size = New System.Drawing.Size(52, 22)
        Me.t40.TabIndex = 44
        '
        't30
        '
        Me.t30.Enabled = False
        Me.t30.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t30.Location = New System.Drawing.Point(361, 160)
        Me.t30.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.t30.Name = "t30"
        Me.t30.Size = New System.Drawing.Size(52, 22)
        Me.t30.TabIndex = 43
        '
        't20
        '
        Me.t20.Enabled = False
        Me.t20.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t20.Location = New System.Drawing.Point(361, 117)
        Me.t20.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.t20.Name = "t20"
        Me.t20.Size = New System.Drawing.Size(52, 22)
        Me.t20.TabIndex = 42
        '
        't10
        '
        Me.t10.Enabled = False
        Me.t10.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.t10.Location = New System.Drawing.Point(361, 76)
        Me.t10.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.t10.Name = "t10"
        Me.t10.Size = New System.Drawing.Size(52, 22)
        Me.t10.TabIndex = 41
        '
        'tUAS
        '
        Me.tUAS.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tUAS.Location = New System.Drawing.Point(166, 196)
        Me.tUAS.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.tUAS.Name = "tUAS"
        Me.tUAS.Size = New System.Drawing.Size(60, 22)
        Me.tUAS.TabIndex = 40
        '
        'tUTS
        '
        Me.tUTS.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tUTS.Location = New System.Drawing.Point(166, 157)
        Me.tUTS.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.tUTS.Name = "tUTS"
        Me.tUTS.Size = New System.Drawing.Size(60, 22)
        Me.tUTS.TabIndex = 39
        '
        'tTugas
        '
        Me.tTugas.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tTugas.Location = New System.Drawing.Point(166, 118)
        Me.tTugas.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.tTugas.Name = "tTugas"
        Me.tTugas.Size = New System.Drawing.Size(60, 22)
        Me.tTugas.TabIndex = 38
        '
        'tAbsen
        '
        Me.tAbsen.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tAbsen.Location = New System.Drawing.Point(166, 77)
        Me.tAbsen.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.tAbsen.Name = "tAbsen"
        Me.tAbsen.Size = New System.Drawing.Size(60, 22)
        Me.tAbsen.TabIndex = 37
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.Color.White
        Me.Label11.Location = New System.Drawing.Point(282, 338)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(69, 16)
        Me.Label11.TabIndex = 36
        Me.Label11.Text = "Keterangan"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.Color.White
        Me.Label10.Location = New System.Drawing.Point(282, 303)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(39, 16)
        Me.Label10.TabIndex = 35
        Me.Label10.Text = "Grade"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.Color.White
        Me.Label9.Location = New System.Drawing.Point(282, 268)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(60, 16)
        Me.Label9.TabIndex = 34
        Me.Label9.Text = "Total Nilai"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.Color.White
        Me.Label8.Location = New System.Drawing.Point(294, 202)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(29, 16)
        Me.Label8.TabIndex = 33
        Me.Label8.Text = "40%"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.Color.White
        Me.Label7.Location = New System.Drawing.Point(294, 160)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(29, 16)
        Me.Label7.TabIndex = 32
        Me.Label7.Text = "30%"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.Color.White
        Me.Label6.Location = New System.Drawing.Point(294, 117)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(29, 16)
        Me.Label6.TabIndex = 31
        Me.Label6.Text = "20%"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.Color.White
        Me.Label5.Location = New System.Drawing.Point(294, 80)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(29, 16)
        Me.Label5.TabIndex = 30
        Me.Label5.Text = "10%"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.Color.White
        Me.Label4.Location = New System.Drawing.Point(88, 203)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(57, 16)
        Me.Label4.TabIndex = 29
        Me.Label4.Text = "Nilai UAS"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.Color.White
        Me.Label3.Location = New System.Drawing.Point(88, 161)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(56, 16)
        Me.Label3.TabIndex = 28
        Me.Label3.Text = "Nilai UTS"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(88, 119)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(66, 16)
        Me.Label2.TabIndex = 27
        Me.Label2.Text = "Nilai Tugas"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial Narrow", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(88, 77)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(67, 16)
        Me.Label1.TabIndex = 26
        Me.Label1.Text = "Nilai Absen"
        '
        'Percabangan_If
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DodgerBlue
        Me.ClientSize = New System.Drawing.Size(539, 421)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnReset)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.tKet)
        Me.Controls.Add(Me.tGrade)
        Me.Controls.Add(Me.tTotal)
        Me.Controls.Add(Me.t40)
        Me.Controls.Add(Me.t30)
        Me.Controls.Add(Me.t20)
        Me.Controls.Add(Me.t10)
        Me.Controls.Add(Me.tUAS)
        Me.Controls.Add(Me.tUTS)
        Me.Controls.Add(Me.tTugas)
        Me.Controls.Add(Me.tAbsen)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.ForeColor = System.Drawing.Color.White
        Me.Name = "Percabangan_If"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Program Percabangan If"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Label12 As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents btnReset As Button
    Friend WithEvents btnCalculate As Button
    Friend WithEvents tKet As TextBox
    Friend WithEvents tGrade As TextBox
    Friend WithEvents tTotal As TextBox
    Friend WithEvents t40 As TextBox
    Friend WithEvents t30 As TextBox
    Friend WithEvents t20 As TextBox
    Friend WithEvents t10 As TextBox
    Friend WithEvents tUAS As TextBox
    Friend WithEvents tUTS As TextBox
    Friend WithEvents tTugas As TextBox
    Friend WithEvents tAbsen As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class
