﻿Public Class BulanIndex
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim NamaBulan() As String = {"Januari", "Februari", "Maret", "April", "Mei", "Juni",
            "Juli", "Agustus", "Sepetember", "Oktober", "November", "Desember"}
        MsgBox(NamaBulan(0))

    End Sub
End Class