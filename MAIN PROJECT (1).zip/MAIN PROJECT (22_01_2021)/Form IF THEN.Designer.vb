﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form_IF_THEN
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Proses = New System.Windows.Forms.Button()
        Me.TKET = New System.Windows.Forms.TextBox()
        Me.Nilai = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Proses
        '
        Me.Proses.BackColor = System.Drawing.Color.DodgerBlue
        Me.Proses.FlatAppearance.BorderSize = 0
        Me.Proses.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Proses.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Proses.ForeColor = System.Drawing.SystemColors.Control
        Me.Proses.Location = New System.Drawing.Point(88, 119)
        Me.Proses.Margin = New System.Windows.Forms.Padding(2)
        Me.Proses.Name = "Proses"
        Me.Proses.Size = New System.Drawing.Size(191, 36)
        Me.Proses.TabIndex = 9
        Me.Proses.Text = "PROSES"
        Me.Proses.UseVisualStyleBackColor = False
        '
        'TKET
        '
        Me.TKET.Enabled = False
        Me.TKET.Location = New System.Drawing.Point(201, 182)
        Me.TKET.Margin = New System.Windows.Forms.Padding(2)
        Me.TKET.Name = "TKET"
        Me.TKET.Size = New System.Drawing.Size(78, 20)
        Me.TKET.TabIndex = 8
        '
        'Nilai
        '
        Me.Nilai.Location = New System.Drawing.Point(203, 82)
        Me.Nilai.Margin = New System.Windows.Forms.Padding(2)
        Me.Nilai.Name = "Nilai"
        Me.Nilai.Size = New System.Drawing.Size(76, 20)
        Me.Nilai.TabIndex = 7
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label2.Location = New System.Drawing.Point(85, 182)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(72, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Keterangan"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label1.Location = New System.Drawing.Point(85, 82)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(65, 13)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Nilai Akhir"
        '
        'Form_IF_THEN
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(374, 305)
        Me.Controls.Add(Me.Proses)
        Me.Controls.Add(Me.TKET)
        Me.Controls.Add(Me.Nilai)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Margin = New System.Windows.Forms.Padding(2, 2, 2, 2)
        Me.Name = "Form_IF_THEN"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form_IF_THEN"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Proses As Button
    Friend WithEvents TKET As TextBox
    Friend WithEvents Nilai As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
End Class
