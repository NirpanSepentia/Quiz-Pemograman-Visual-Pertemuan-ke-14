﻿Imports System.Data
Imports System.Data.OleDb
Public Class poppeg
    Public colNIP, colNama, colbgn, coltgllhr, colAlamat, colpend, colstatus As String
    Dim cnn As OleDbConnection
    Dim cmmd As OleDbCommand
    Dim dReader As OleDbDataReader
    Private Sub clear_list()
        While Val(counter.Text) > 0
            ListView1.Items(0).Remove()
            counter.Text = Val(counter.Text) - 1
        End While
    End Sub

    Private Sub btnReport_Click(sender As Object, e As EventArgs) Handles btnReport.Click
        ReportKaryawan.Show()
    End Sub

    Private Sub pilih()
        Try
            colNIP = ListView1.SelectedItems(0).SubItems(0).Text.ToString
            colNama = ListView1.SelectedItems(0).SubItems(1).Text.ToString
            colbgn = ListView1.SelectedItems(0).SubItems(2).Text.ToString
            coltgllhr = ListView1.SelectedItems(0).SubItems(3).Text.ToString
            colAlamat = ListView1.SelectedItems(0).SubItems(4).Text.ToString
            colpend = ListView1.SelectedItems(0).SubItems(5).Text.ToString
            colstatus = ListView1.SelectedItems(0).SubItems(6).Text.ToString

            Me.Close()

        Catch ex As Exception
            MsgBox("Pilih salah satu data", MsgBoxStyle.Information)
        End Try
    End Sub
    Public Sub list_data()
        Call clear_list()

        Dim sqlx As String
        Dim x As Integer
        sqlx = "select NIP,NamaPgw,Bagian,TglLhr,Alamat,Pendidikan,Status from pegawai where NamaPgw like '%" & Trim(tNama.Text) & "%' order by NamaPgw asc"

        cnn = New OleDbConnection(KONEKSI)
        If cnn.State <> ConnectionState.Closed Then cnn.Close()
        cnn.Open()
        cmmd = New OleDbCommand(sqlx, cnn)
        dReader = cmmd.ExecuteReader
        Try
            While dReader.Read = True
                x = Val(counter.Text)
                counter.Text = Str(Val(counter.Text) + 1) & " Record"

                With ListView1
                    .Items.Add("")
                    .Items(ListView1.Items.Count - 1).SubItems.Add("")
                    .Items(ListView1.Items.Count - 1).SubItems.Add("")
                    .Items(ListView1.Items.Count - 1).SubItems.Add("")
                    .Items(ListView1.Items.Count - 1).SubItems.Add("")
                    .Items(ListView1.Items.Count - 1).SubItems.Add("")
                    .Items(ListView1.Items.Count - 1).SubItems.Add("")
                    .Items(ListView1.Items.Count - 1).SubItems.Add("")
                    .Items(x).SubItems(0).Text = dReader.GetString(0)
                    .Items(x).SubItems(1).Text = dReader.GetString(1)
                    .Items(x).SubItems(2).Text = dReader.GetString(2)
                    .Items(x).SubItems(3).Text = dReader.GetDateTime(3)
                    .Items(x).SubItems(4).Text = dReader.GetString(4)
                    .Items(x).SubItems(5).Text = dReader.GetString(5)
                    .Items(x).SubItems(6).Text = dReader.GetString(6)
                End With
            End While
        Finally
            dReader.Close()
        End Try
        cnn.Close()
    End Sub
    Private Sub poppeg_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call list_data()

    End Sub

    Private Sub btnOK_Click(sender As Object, e As EventArgs) Handles btnOK.Click
        Call pilih()
    End Sub

    Private Sub ListView1_DoubleClick(sender As Object, e As EventArgs) Handles ListView1.DoubleClick
        Call pilih()

    End Sub

    Private Sub tNama_TextChanged(sender As Object, e As EventArgs) Handles tNama.TextChanged
        Call list_data()
    End Sub
End Class